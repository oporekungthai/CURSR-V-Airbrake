/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: control.c
 *
 * Code generated for Simulink model 'control'.
 *
 * Model version                  : 1.10
 * Simulink Coder version         : 24.1 (R2024a) 19-Nov-2023
 * C/C++ source code generated on : Tue May 19 16:28:41 2026
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "control.h"
#include "rtwtypes.h"
#include "rt_nonfinite.h"
#include <math.h>
#include "control_private.h"
#include <string.h>

/* Block signals (default storage) */
B_control_T control_B;

/* Block states (default storage) */
DW_control_T control_DW;

/* External inputs (root inport signals with default storage) */
ExtU_control_T control_U;

/* External outputs (root outports fed by signals with default storage) */
ExtY_control_T control_Y;

/* Real-time model */
static RT_MODEL_control_T control_M_;
RT_MODEL_control_T *const control_M = &control_M_;

/* Forward declaration for local functions */
static real_T control_interp1(const real_T varargin_1[26], const real_T
  varargin_2[26], real_T varargin_3);
static real_T control_interp1_k(const real_T varargin_1[370], const real_T
  varargin_2[370], real_T varargin_3);
static void control_RK2(real_T h, real_T v, real_T pitch, real_T u_val, const
  real_T M_b[26], const real_T C_b[26], const real_T M_off[370], const real_T
  Cdr_off[370], real_T *h_final, real_T *bf, real_T *f);
real_T rt_powd_snf(real_T u0, real_T u1)
{
  real_T y;
  if (rtIsNaN(u0) || rtIsNaN(u1)) {
    y = (rtNaN);
  } else {
    real_T tmp;
    real_T tmp_0;
    tmp = fabs(u0);
    tmp_0 = fabs(u1);
    if (rtIsInf(u1)) {
      if (tmp == 1.0) {
        y = 1.0;
      } else if (tmp > 1.0) {
        if (u1 > 0.0) {
          y = (rtInf);
        } else {
          y = 0.0;
        }
      } else if (u1 > 0.0) {
        y = 0.0;
      } else {
        y = (rtInf);
      }
    } else if (tmp_0 == 0.0) {
      y = 1.0;
    } else if (tmp_0 == 1.0) {
      if (u1 > 0.0) {
        y = u0;
      } else {
        y = 1.0 / u0;
      }
    } else if (u1 == 2.0) {
      y = u0 * u0;
    } else if ((u1 == 0.5) && (u0 >= 0.0)) {
      y = sqrt(u0);
    } else if ((u0 < 0.0) && (u1 > floor(u1))) {
      y = (rtNaN);
    } else {
      y = pow(u0, u1);
    }
  }

  return y;
}

/* Function for MATLAB Function: '<S2>/NAP Function' */
static real_T control_interp1(const real_T varargin_1[26], const real_T
  varargin_2[26], real_T varargin_3)
{
  real_T Vq;
  int32_T i;
  memcpy(&control_B.y_m[0], &varargin_2[0], 26U * sizeof(real_T));
  memcpy(&control_B.x_c[0], &varargin_1[0], 26U * sizeof(real_T));
  Vq = 0.0;
  i = 0;
  int32_T exitg1;
  do {
    exitg1 = 0;
    if (i < 26) {
      if (rtIsNaN(varargin_1[i])) {
        exitg1 = 1;
      } else {
        i++;
      }
    } else {
      real_T xtmp;
      if (varargin_1[1] < varargin_1[0]) {
        for (i = 0; i < 13; i++) {
          xtmp = control_B.x_c[i];
          control_B.x_c[i] = control_B.x_c[25 - i];
          control_B.x_c[25 - i] = xtmp;
          xtmp = control_B.y_m[i];
          control_B.y_m[i] = control_B.y_m[25 - i];
          control_B.y_m[25 - i] = xtmp;
        }
      }

      if (rtIsNaN(varargin_3)) {
        Vq = (rtNaN);
      } else if (varargin_3 > control_B.x_c[25]) {
        Vq = (varargin_3 - control_B.x_c[25]) / (control_B.x_c[25] -
          control_B.x_c[24]) * (control_B.y_m[25] - control_B.y_m[24]) +
          control_B.y_m[25];
      } else if (varargin_3 < control_B.x_c[0]) {
        Vq = (varargin_3 - control_B.x_c[0]) / (control_B.x_c[1] -
          control_B.x_c[0]) * (control_B.y_m[1] - control_B.y_m[0]) +
          control_B.y_m[0];
      } else {
        int32_T low_i;
        int32_T low_ip1;
        i = 26;
        low_i = 1;
        low_ip1 = 2;
        while (i > low_ip1) {
          int32_T mid_i;
          mid_i = (low_i + i) >> 1;
          if (varargin_3 >= control_B.x_c[mid_i - 1]) {
            low_i = mid_i;
            low_ip1 = mid_i + 1;
          } else {
            i = mid_i;
          }
        }

        xtmp = control_B.x_c[low_i - 1];
        xtmp = (varargin_3 - xtmp) / (control_B.x_c[low_i] - xtmp);
        if (xtmp == 0.0) {
          Vq = control_B.y_m[low_i - 1];
        } else if (xtmp == 1.0) {
          Vq = control_B.y_m[low_i];
        } else {
          Vq = control_B.y_m[low_i - 1];
          if (!(Vq == control_B.y_m[low_i])) {
            Vq = (1.0 - xtmp) * Vq + xtmp * control_B.y_m[low_i];
          }
        }
      }

      exitg1 = 1;
    }
  } while (exitg1 == 0);

  return Vq;
}

/* Function for MATLAB Function: '<S2>/NAP Function' */
static real_T control_interp1_k(const real_T varargin_1[370], const real_T
  varargin_2[370], real_T varargin_3)
{
  real_T Vq;
  int32_T i;
  memcpy(&control_B.y[0], &varargin_2[0], 370U * sizeof(real_T));
  memcpy(&control_B.x[0], &varargin_1[0], 370U * sizeof(real_T));
  Vq = 0.0;
  i = 0;
  int32_T exitg1;
  do {
    exitg1 = 0;
    if (i < 370) {
      if (rtIsNaN(varargin_1[i])) {
        exitg1 = 1;
      } else {
        i++;
      }
    } else {
      real_T xtmp;
      if (varargin_1[1] < varargin_1[0]) {
        for (i = 0; i < 185; i++) {
          xtmp = control_B.x[i];
          control_B.x[i] = control_B.x[369 - i];
          control_B.x[369 - i] = xtmp;
          xtmp = control_B.y[i];
          control_B.y[i] = control_B.y[369 - i];
          control_B.y[369 - i] = xtmp;
        }
      }

      if (rtIsNaN(varargin_3)) {
        Vq = (rtNaN);
      } else if (varargin_3 > control_B.x[369]) {
        Vq = (varargin_3 - control_B.x[369]) / (control_B.x[369] - control_B.x
          [368]) * (control_B.y[369] - control_B.y[368]) + control_B.y[369];
      } else if (varargin_3 < control_B.x[0]) {
        Vq = (varargin_3 - control_B.x[0]) / (control_B.x[1] - control_B.x[0]) *
          (control_B.y[1] - control_B.y[0]) + control_B.y[0];
      } else {
        int32_T low_i;
        int32_T low_ip1;
        i = 370;
        low_i = 1;
        low_ip1 = 2;
        while (i > low_ip1) {
          int32_T mid_i;
          mid_i = (low_i + i) >> 1;
          if (varargin_3 >= control_B.x[mid_i - 1]) {
            low_i = mid_i;
            low_ip1 = mid_i + 1;
          } else {
            i = mid_i;
          }
        }

        xtmp = control_B.x[low_i - 1];
        xtmp = (varargin_3 - xtmp) / (control_B.x[low_i] - xtmp);
        if (xtmp == 0.0) {
          Vq = control_B.y[low_i - 1];
        } else if (xtmp == 1.0) {
          Vq = control_B.y[low_i];
        } else {
          Vq = control_B.y[low_i - 1];
          if (!(Vq == control_B.y[low_i])) {
            Vq = (1.0 - xtmp) * Vq + xtmp * control_B.y[low_i];
          }
        }
      }

      exitg1 = 1;
    }
  } while (exitg1 == 0);

  return Vq;
}

/* Function for MATLAB Function: '<S2>/NAP Function' */
static void control_RK2(real_T h, real_T v, real_T pitch, real_T u_val, const
  real_T M_b[26], const real_T C_b[26], const real_T M_off[370], const real_T
  Cdr_off[370], real_T *h_final, real_T *bf, real_T *f)
{
  real_T T0;
  real_T T2;
  real_T mach0;
  real_T stream0_tmp;
  int32_T iter_rk;
  boolean_T exitg1;
  *h_final = h;
  control_B.v1 = v;
  stream0_tmp = cos(pitch);
  control_B.stream0 = v / stream0_tmp;
  T0 = 288.15 - 0.0065 * h;
  mach0 = control_B.stream0 / sqrt(401.87391999999994 * T0);
  control_B.stream0 = rt_powd_snf(T0 / 288.15, 5.2558) * 101325.0 / (287.0528 *
    T0) * -0.5 * (control_B.stream0 * control_B.stream0);
  *bf = control_B.stream0 * control_interp1(M_b, C_b, mach0) * 0.002222324 /
    25.142 * stream0_tmp;
  *f = control_B.stream0 * control_interp1_k(M_off, Cdr_off, mach0) *
    0.013478217882063612 / 25.142 * stream0_tmp - 9.81;
  iter_rk = 0;
  exitg1 = false;
  while ((!exitg1) && ((iter_rk < 500) && (!(control_B.v1 < 0.0)))) {
    control_B.stream0 = control_B.v1 / stream0_tmp;
    T0 = 288.15 - 0.0065 * *h_final;
    mach0 = control_B.stream0 / sqrt(401.87391999999994 * T0);
    control_B.stream0 = rt_powd_snf(T0 / 288.15, 5.2558) * 101325.0 / (287.0528 *
      T0) * -0.5 * (control_B.stream0 * control_B.stream0);
    mach0 = ((control_B.stream0 * control_interp1_k(M_off, Cdr_off, mach0) *
              0.013478217882063612 / 25.142 * stream0_tmp - 9.81) +
             control_B.stream0 * control_interp1(M_b, C_b, mach0) * 0.002222324 /
             25.142 * stream0_tmp * u_val) * 0.05 + control_B.v1;
    T0 = mach0 / stream0_tmp;
    T2 = 288.15 - (control_B.v1 * 0.05 + *h_final) * 0.0065;
    control_B.stream0 = T0 / sqrt(401.87391999999994 * T2);
    T0 = rt_powd_snf(T2 / 288.15, 5.2558) * 101325.0 / (287.0528 * T2) * -0.5 *
      (T0 * T0);
    control_B.v1 += ((T0 * control_interp1_k(M_off, Cdr_off, control_B.stream0) *
                      0.013478217882063612 / 25.142 * stream0_tmp - 9.81) + T0 *
                     control_interp1(M_b, C_b, control_B.stream0) * 0.002222324 /
                     25.142 * stream0_tmp * u_val) * 0.1;
    *h_final += mach0 * 0.1;
    if (*h_final > 12000.0) {
      exitg1 = true;
    } else {
      iter_rk++;
    }
  }
}

/* Model step function for TID0 */
void control_step0(void)               /* Sample time: [0.001s, 0.0s] */
{
  real_T b0;
  real_T e;
  real_T f0;
  real_T u0;

  /* Update the flag to indicate when data transfers from
   *  Sample time: [0.001s, 0.0s] to Sample time: [0.01s, 0.0s]  */
  (control_M->Timing.RateInteraction.TID0_1)++;
  if ((control_M->Timing.RateInteraction.TID0_1) > 9) {
    control_M->Timing.RateInteraction.TID0_1 = 0;
  }

  /* RateTransition generated from: '<Root>/Delay' incorporates:
   *  Delay: '<Root>/Delay'
   */
  if (control_M->Timing.RateInteraction.TID0_1 == 1) {
    control_DW.TmpRTBAtDelayOutport1_Buffer[0] = control_DW.Delay_DSTATE[0];
    control_DW.TmpRTBAtDelayOutport1_Buffer[1] = control_DW.Delay_DSTATE[1];
  }

  /* End of RateTransition generated from: '<Root>/Delay' */

  /* Switch: '<Root>/Switch' incorporates:
   *  Inport: '<Root>/logic'
   */
  if (control_U.logic) {
    /* Outport: '<Root>/Out1' incorporates:
     *  Delay: '<Root>/Delay2'
     */
    control_Y.Out1 = control_DW.Delay2_DSTATE[0];
  } else {
    /* Outport: '<Root>/Out1' incorporates:
     *  Constant: '<Root>/Constant'
     */
    control_Y.Out1 = 0.0;
  }

  /* End of Switch: '<Root>/Switch' */

  /* RateTransition generated from: '<Root>/Enabled Subsystem' incorporates:
   *  Delay: '<Root>/Delay1'
   */
  if (control_M->Timing.RateInteraction.TID0_1 == 1) {
    control_DW.TmpRTBAtEnabledSubsystemInport3 = control_DW.Delay1_DSTATE[0];

    /* RateTransition generated from: '<Root>/Enabled Subsystem' incorporates:
     *  Delay: '<Root>/Delay1'
     */
    control_B.TmpRTBAtEnabledSubsystemOutport =
      control_DW.TmpRTBAtEnabledSubsystemOutport;

    /* RateTransition generated from: '<Root>/Enabled Subsystem' */
    control_B.TmpRTBAtEnabledSubsystemOutpo_o =
      control_DW.TmpRTBAtEnabledSubsystemOutpo_h;

    /* RateTransition generated from: '<Root>/Enabled Subsystem' */
    control_B.TmpRTBAtEnabledSubsystemOutpo_f =
      control_DW.TmpRTBAtEnabledSubsystemOutpo_m;
  }

  /* End of RateTransition generated from: '<Root>/Enabled Subsystem' */

  /* MATLAB Function: '<Root>/ESO Function' incorporates:
   *  Inport: '<Root>/Vz'
   *  Inport: '<Root>/h'
   */
  u0 = control_B.TmpRTBAtEnabledSubsystemOutport;
  b0 = control_B.TmpRTBAtEnabledSubsystemOutpo_o;
  f0 = control_B.TmpRTBAtEnabledSubsystemOutpo_f;
  if (rtIsNaN(control_B.TmpRTBAtEnabledSubsystemOutport)) {
    u0 = 0.0;
  }

  if (rtIsNaN(control_B.TmpRTBAtEnabledSubsystemOutpo_o)) {
    b0 = -5.0;
  } else if (control_B.TmpRTBAtEnabledSubsystemOutpo_o == 0.0) {
    b0 = -5.0;
  }

  if (rtIsNaN(control_B.TmpRTBAtEnabledSubsystemOutpo_f)) {
    f0 = -9.81;
  }

  if (!control_DW.z1_not_empty) {
    control_DW.z1 = 892.0;
    control_DW.z1_not_empty = true;
    control_DW.z2 = 0.0;
    control_DW.z3 = -9.81;
    control_DW.u_prev = 0.0;
    if (!rtIsNaN(control_U.h)) {
      control_DW.z1 = control_U.h;
    }

    if (!rtIsNaN(control_U.Vz)) {
      control_DW.z2 = control_U.Vz;
    }

    if (!rtIsNaN(f0)) {
      control_DW.z3 = f0;
    }
  }

  if (rtIsNaN(control_U.h) || rtIsNaN(control_U.Vz)) {
  } else {
    e = control_DW.z1 - control_U.h;
    control_DW.u_prev = fmax(0.0, fmin(1.0, fmax(fmin((fmax(-0.5, fmin(0.5,
      -control_DW.z3 / b0)) + u0) - control_DW.u_prev, 0.3), -0.3) +
      control_DW.u_prev));
    control_DW.z1 += (control_DW.z2 - 18.0 * e) * 0.001;
    control_DW.z2 += (((control_DW.z3 + f0) - 108.0 * e) + b0 *
                      control_DW.u_prev) * 0.001;
    control_DW.z3 += -216.0 * e * 0.001;
  }

  /* Outputs for Enabled SubSystem: '<Root>/Enabled Subsystem' incorporates:
   *  EnablePort: '<S2>/Enable'
   */
  /* Inport: '<Root>/logic' */
  if (control_U.logic) {
    if (!control_DW.EnabledSubsystem_MODE) {
      control_DW.EnabledSubsystem_MODE = true;
    }
  } else if (control_DW.EnabledSubsystem_MODE) {
    control_DW.EnabledSubsystem_MODE = false;
  }

  /* End of Outputs for SubSystem: '<Root>/Enabled Subsystem' */

  /* Update for Delay: '<Root>/Delay' */
  control_DW.Delay_DSTATE[0] = control_DW.Delay_DSTATE[2];
  control_DW.Delay_DSTATE[1] = control_DW.Delay_DSTATE[3];
  control_DW.Delay_DSTATE[2] = control_DW.z1;
  control_DW.Delay_DSTATE[3] = control_DW.z2;

  /* Update for Delay: '<Root>/Delay2' incorporates:
   *  MATLAB Function: '<Root>/ESO Function'
   */
  control_DW.Delay2_DSTATE[0] = control_DW.Delay2_DSTATE[1];
  control_DW.Delay2_DSTATE[1] = control_DW.u_prev;

  /* Update for Delay: '<Root>/Delay1' incorporates:
   *  Inport: '<Root>/pitch'
   */
  control_DW.Delay1_DSTATE[0] = control_DW.Delay1_DSTATE[1];
  control_DW.Delay1_DSTATE[1] = control_U.pitch;
}

/* Model step function for TID1 */
void control_step1(void)               /* Sample time: [0.01s, 0.0s] */
{
  int32_T iter;
  boolean_T guard1;

  /* Outputs for Enabled SubSystem: '<Root>/Enabled Subsystem' incorporates:
   *  EnablePort: '<S2>/Enable'
   */
  if (control_DW.EnabledSubsystem_MODE) {
    /* Delay: '<S2>/Delay' */
    control_B.Delay = control_DW.Delay_DSTATE_h[0];

    /* Delay: '<S2>/Delay1' */
    control_B.Delay1 = control_DW.Delay1_DSTATE_h[0];

    /* Delay: '<S2>/Delay2' */
    control_B.Delay2 = control_DW.Delay2_DSTATE_i[0];

    /* MATLAB Function: '<S2>/NAP Function' incorporates:
     *  Constant: '<S2>/Constant'
     *  Constant: '<S2>/Constant1'
     *  Constant: '<S2>/Constant2'
     *  Constant: '<S2>/Constant3'
     *  RateTransition generated from: '<Root>/Delay'
     *  RateTransition generated from: '<Root>/Enabled Subsystem'
     */
    control_B.u_out = 0.0;
    control_B.bf = -4.5;
    control_B.f_nominal = -9.81;
    if ((!rtIsNaN(control_DW.TmpRTBAtDelayOutport1_Buffer[0])) && (!rtIsNaN
         (control_DW.TmpRTBAtDelayOutport1_Buffer[1]))) {
      guard1 = false;
      if (control_DW.tick <= 0.0) {
        control_RK2(control_DW.TmpRTBAtDelayOutport1_Buffer[0],
                    control_DW.TmpRTBAtDelayOutport1_Buffer[1],
                    control_DW.TmpRTBAtEnabledSubsystemInport3, 0.0,
                    control_ConstP.Constant_Value,
                    control_ConstP.Constant1_Value,
                    control_ConstP.Constant2_Value,
                    control_ConstP.Constant3_Value, &control_B.h_pred_min,
                    &control_B.bf, &control_B.f_nominal);
        if (control_B.h_pred_min < 11072.32) {
        } else {
          control_RK2(control_DW.TmpRTBAtDelayOutport1_Buffer[0],
                      control_DW.TmpRTBAtDelayOutport1_Buffer[1],
                      control_DW.TmpRTBAtEnabledSubsystemInport3, 1.0,
                      control_ConstP.Constant_Value,
                      control_ConstP.Constant1_Value,
                      control_ConstP.Constant2_Value,
                      control_ConstP.Constant3_Value, &control_B.u_out,
                      &control_B.bf, &control_B.f_nominal);
          if (control_B.u_out > 11072.32) {
            control_B.u_out = 1.0;
          } else {
            control_B.bf = 0.0;
            control_B.f_nominal = 1.0;
            control_DW.u_store = 0.5;
            for (iter = 0; iter < 5; iter++) {
              control_RK2(control_DW.TmpRTBAtDelayOutport1_Buffer[0],
                          control_DW.TmpRTBAtDelayOutport1_Buffer[1],
                          control_DW.TmpRTBAtEnabledSubsystemInport3,
                          control_DW.u_store, control_ConstP.Constant_Value,
                          control_ConstP.Constant1_Value,
                          control_ConstP.Constant2_Value,
                          control_ConstP.Constant3_Value, &control_B.u_out,
                          &control_DW.bf_store, &control_DW.f_store);
              if (control_B.u_out > 11072.32) {
                control_B.bf = control_DW.u_store;
              } else {
                control_B.f_nominal = control_DW.u_store;
              }

              control_DW.u_store = (control_B.bf + control_B.f_nominal) / 2.0;
            }

            control_DW.tick = 10.0;
            guard1 = true;
          }
        }
      } else {
        guard1 = true;
      }

      if (guard1) {
        control_DW.tick--;
        control_B.u_out = control_DW.u_store;
        control_B.bf = control_DW.bf_store;
        control_B.f_nominal = control_DW.f_store;
      }
    }

    /* End of MATLAB Function: '<S2>/NAP Function' */

    /* Update for Delay: '<S2>/Delay' */
    control_DW.Delay_DSTATE_h[0] = control_DW.Delay_DSTATE_h[1];
    control_DW.Delay_DSTATE_h[1] = control_B.u_out;

    /* Update for Delay: '<S2>/Delay1' */
    control_DW.Delay1_DSTATE_h[0] = control_DW.Delay1_DSTATE_h[1];
    control_DW.Delay1_DSTATE_h[1] = control_B.bf;

    /* Update for Delay: '<S2>/Delay2' */
    control_DW.Delay2_DSTATE_i[0] = control_DW.Delay2_DSTATE_i[1];
    control_DW.Delay2_DSTATE_i[1] = control_B.f_nominal;
  }

  /* End of Outputs for SubSystem: '<Root>/Enabled Subsystem' */

  /* RateTransition generated from: '<Root>/Enabled Subsystem' */
  control_DW.TmpRTBAtEnabledSubsystemOutport = control_B.Delay;

  /* RateTransition generated from: '<Root>/Enabled Subsystem' */
  control_DW.TmpRTBAtEnabledSubsystemOutpo_h = control_B.Delay1;

  /* RateTransition generated from: '<Root>/Enabled Subsystem' */
  control_DW.TmpRTBAtEnabledSubsystemOutpo_m = control_B.Delay2;
}

/* Model initialize function */
void control_initialize(void)
{
  /* Registration code */

  /* Set task counter limit used by the static main program */
  (control_M)->Timing.TaskCounters.cLimit[0] = 1;
  (control_M)->Timing.TaskCounters.cLimit[1] = 10;

  /* SystemInitialize for Enabled SubSystem: '<Root>/Enabled Subsystem' */
  /* SystemInitialize for MATLAB Function: '<S2>/NAP Function' */
  control_DW.bf_store = -4.5;
  control_DW.f_store = -9.81;

  /* End of SystemInitialize for SubSystem: '<Root>/Enabled Subsystem' */
}

/* Model terminate function */
void control_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
