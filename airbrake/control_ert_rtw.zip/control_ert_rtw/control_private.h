/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: control_private.h
 *
 * Code generated for Simulink model 'control'.
 *
 * Model version                  : 1.10
 * Simulink Coder version         : 24.1 (R2024a) 19-Nov-2023
 * C/C++ source code generated on : Tue May 19 16:28:41 2026
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef control_private_h_
#define control_private_h_
#include "rtwtypes.h"
#include "control_types.h"

extern real_T rt_powd_snf(real_T u0, real_T u1);

#endif                                 /* control_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
