function CodeMetrics() {
	 this.metricsArray = {};
	 this.metricsArray.var = new Array();
	 this.metricsArray.fcn = new Array();
	 this.metricsArray.var["control.c:control_M_"] = {file: "C:\\simulan\\sim_airbrake\\airbrake\\control_ert_rtw\\control.c",
	size: 12};
	 this.metricsArray.var["control_B"] = {file: "C:\\simulan\\sim_airbrake\\airbrake\\control_ert_rtw\\control.c",
	size: 6432};
	 this.metricsArray.var["control_DW"] = {file: "C:\\simulan\\sim_airbrake\\airbrake\\control_ert_rtw\\control.c",
	size: 232};
	 this.metricsArray.var["control_U"] = {file: "C:\\simulan\\sim_airbrake\\airbrake\\control_ert_rtw\\control.c",
	size: 32};
	 this.metricsArray.var["control_Y"] = {file: "C:\\simulan\\sim_airbrake\\airbrake\\control_ert_rtw\\control.c",
	size: 8};
	 this.metricsArray.var["rtInf"] = {file: "C:\\simulan\\sim_airbrake\\airbrake\\control_ert_rtw\\rt_nonfinite.c",
	size: 8};
	 this.metricsArray.var["rtInfF"] = {file: "C:\\simulan\\sim_airbrake\\airbrake\\control_ert_rtw\\rt_nonfinite.c",
	size: 4};
	 this.metricsArray.var["rtMinusInf"] = {file: "C:\\simulan\\sim_airbrake\\airbrake\\control_ert_rtw\\rt_nonfinite.c",
	size: 8};
	 this.metricsArray.var["rtMinusInfF"] = {file: "C:\\simulan\\sim_airbrake\\airbrake\\control_ert_rtw\\rt_nonfinite.c",
	size: 4};
	 this.metricsArray.var["rtNaN"] = {file: "C:\\simulan\\sim_airbrake\\airbrake\\control_ert_rtw\\rt_nonfinite.c",
	size: 8};
	 this.metricsArray.var["rtNaNF"] = {file: "C:\\simulan\\sim_airbrake\\airbrake\\control_ert_rtw\\rt_nonfinite.c",
	size: 4};
	 this.metricsArray.fcn["control.c:control_RK2"] = {file: "C:\\simulan\\sim_airbrake\\airbrake\\control_ert_rtw\\control.c",
	stack: 97,
	stackTotal: 166};
	 this.metricsArray.fcn["control.c:control_interp1"] = {file: "C:\\simulan\\sim_airbrake\\airbrake\\control_ert_rtw\\control.c",
	stack: 60,
	stackTotal: 69};
	 this.metricsArray.fcn["control.c:control_interp1_k"] = {file: "C:\\simulan\\sim_airbrake\\airbrake\\control_ert_rtw\\control.c",
	stack: 60,
	stackTotal: 69};
	 this.metricsArray.fcn["control_initialize"] = {file: "C:\\simulan\\sim_airbrake\\airbrake\\control_ert_rtw\\control.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["control_step"] = {file: "C:\\simulan\\sim_airbrake\\airbrake\\control_ert_rtw\\rtmodel.c",
	stack: 4,
	stackTotal: 175};
	 this.metricsArray.fcn["control_step0"] = {file: "C:\\simulan\\sim_airbrake\\airbrake\\control_ert_rtw\\control.c",
	stack: 32,
	stackTotal: 41};
	 this.metricsArray.fcn["control_step1"] = {file: "C:\\simulan\\sim_airbrake\\airbrake\\control_ert_rtw\\control.c",
	stack: 5,
	stackTotal: 171};
	 this.metricsArray.fcn["control_terminate"] = {file: "C:\\simulan\\sim_airbrake\\airbrake\\control_ert_rtw\\control.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["cos"] = {file: "C:\\Program Files\\MATLAB\\R2024a\\polyspace\\verifier\\cxx\\include\\include-libc\\bits\\mathcalls.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["fabs"] = {file: "C:\\Program Files\\MATLAB\\R2024a\\polyspace\\verifier\\cxx\\include\\include-libc\\bits\\mathcalls.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["floor"] = {file: "C:\\Program Files\\MATLAB\\R2024a\\polyspace\\verifier\\cxx\\include\\include-libc\\bits\\mathcalls.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["fmax"] = {file: "C:\\Program Files\\MATLAB\\R2024a\\polyspace\\verifier\\cxx\\include\\include-libc\\bits\\mathcalls.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["fmin"] = {file: "C:\\Program Files\\MATLAB\\R2024a\\polyspace\\verifier\\cxx\\include\\include-libc\\bits\\mathcalls.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["memcpy"] = {file: "C:\\Program Files\\MATLAB\\R2024a\\polyspace\\verifier\\cxx\\include\\include-libc\\string.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["pow"] = {file: "C:\\Program Files\\MATLAB\\R2024a\\polyspace\\verifier\\cxx\\include\\include-libc\\bits\\mathcalls.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["rtGetInf"] = {file: "C:\\simulan\\sim_airbrake\\airbrake\\control_ert_rtw\\rtGetInf.c",
	stack: 8,
	stackTotal: 8};
	 this.metricsArray.fcn["rtGetInfF"] = {file: "C:\\simulan\\sim_airbrake\\airbrake\\control_ert_rtw\\rtGetInf.c",
	stack: 4,
	stackTotal: 4};
	 this.metricsArray.fcn["rtGetMinusInf"] = {file: "C:\\simulan\\sim_airbrake\\airbrake\\control_ert_rtw\\rtGetInf.c",
	stack: 8,
	stackTotal: 8};
	 this.metricsArray.fcn["rtGetMinusInfF"] = {file: "C:\\simulan\\sim_airbrake\\airbrake\\control_ert_rtw\\rtGetInf.c",
	stack: 4,
	stackTotal: 4};
	 this.metricsArray.fcn["rtGetNaN"] = {file: "C:\\simulan\\sim_airbrake\\airbrake\\control_ert_rtw\\rtGetNaN.c",
	stack: 8,
	stackTotal: 8};
	 this.metricsArray.fcn["rtGetNaNF"] = {file: "C:\\simulan\\sim_airbrake\\airbrake\\control_ert_rtw\\rtGetNaN.c",
	stack: 4,
	stackTotal: 4};
	 this.metricsArray.fcn["rtIsInf"] = {file: "C:\\simulan\\sim_airbrake\\airbrake\\control_ert_rtw\\rt_nonfinite.c",
	stack: 9,
	stackTotal: 9};
	 this.metricsArray.fcn["rtIsInfF"] = {file: "C:\\simulan\\sim_airbrake\\airbrake\\control_ert_rtw\\rt_nonfinite.c",
	stack: 5,
	stackTotal: 5};
	 this.metricsArray.fcn["rtIsNaN"] = {file: "C:\\simulan\\sim_airbrake\\airbrake\\control_ert_rtw\\rt_nonfinite.c",
	stack: 9,
	stackTotal: 9};
	 this.metricsArray.fcn["rtIsNaNF"] = {file: "C:\\simulan\\sim_airbrake\\airbrake\\control_ert_rtw\\rt_nonfinite.c",
	stack: 5,
	stackTotal: 5};
	 this.metricsArray.fcn["rt_powd_snf"] = {file: "C:\\simulan\\sim_airbrake\\airbrake\\control_ert_rtw\\control.c",
	stack: 48,
	stackTotal: 57};
	 this.metricsArray.fcn["sqrt"] = {file: "C:\\Program Files\\MATLAB\\R2024a\\polyspace\\verifier\\cxx\\include\\include-libc\\bits\\mathcalls.h",
	stack: 0,
	stackTotal: 0};
	 this.getMetrics = function(token) { 
		 var data;
		 data = this.metricsArray.var[token];
		 if (!data) {
			 data = this.metricsArray.fcn[token];
			 if (data) data.type = "fcn";
		 } else { 
			 data.type = "var";
		 }
	 return data; }; 
	 this.codeMetricsSummary = '<a href="javascript:void(0)" onclick="return postParentWindowMessage({message:\'gotoReportPage\', pageName:\'control_metrics\'});">Global Memory: 6752(bytes) Maximum Stack: 97(bytes)</a>';
	}
CodeMetrics.instance = new CodeMetrics();
